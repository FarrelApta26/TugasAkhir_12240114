<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Produk;

class ProdukController extends Controller
{
    public function index()
    {
        $produk = Produk::all(); // menampilkan semua produk
        return response()->json($produk, 200);
    }

    public function show($id)
    {
        $produk = Produk::find($id);
        if (!$produk) {
            return response()->json(['message' => 'Produk tidak ditemukan'], 404);
        }
        return response()->json($produk, 200);
    }

    public function update(Request $request, $id)
    {
        $produk = Produk::find($id);
        if (!$produk) {
            return response()->json(['message' => 'Produk tidak ditemukan'], 404);
        }

        $produk->update($request->all());

        return response()->json([
            'message' => 'Produk berhasil diperbarui',
            'data' => $produk
        ], 200);
    }

    public function destroy($id) 
    { 
        $produk = Produk::find($id); 
        if (!$produk) { 
            return response()->json(['message' => 'Produk tidak 
            ditemukan'], 404); 
        } 
        
        $produk->delete(); 
        return response()->json(['message' => 'Produk berhasil dihapus'], 
        200); 
    } 
}
