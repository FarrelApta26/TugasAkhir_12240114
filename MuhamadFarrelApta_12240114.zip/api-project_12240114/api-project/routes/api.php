<?php 
use Illuminate\Http\Request; 
use Illuminate\Support\Facades\Route; 
use App\Http\Controllers\Api\ProdukController;  //Memanggil Controller 
use App\Http\Controllers\AuthController;

Route::get('/tes', function () { 
return response()->json(['message' => 'API Berhasil Terhubung']); 
}); 
//Route::apiResource('produk', ProdukController::class); //Menjalankan controller
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::apiResource('produk', ProdukController::class);

Route::middleware('auth:sanctum')->group(function () {
  // Route::apiResource('produk', ProdukController::class); //Menjalankan controller
    Route::post('/logout', [AuthController::class, 'logout']);
});


