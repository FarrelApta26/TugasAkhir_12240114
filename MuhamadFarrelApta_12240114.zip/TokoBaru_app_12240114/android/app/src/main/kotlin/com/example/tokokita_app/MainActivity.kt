package com.example.tokokita_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
