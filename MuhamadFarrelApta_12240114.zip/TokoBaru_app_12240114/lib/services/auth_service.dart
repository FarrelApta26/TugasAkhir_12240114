import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  final String baseUrl = "http://localhost:8000/api";

  Future<bool> register(String nama, String email, String password) async {
    final response = await http.post(
      Uri.parse("$baseUrl/register"),
      body: {"nama": nama, "email": email, "password": password},
    );

    if (response.statusCode == 200 || response.statusCode == 201) {
      final data = jsonDecode(response.body);
      return data['message'] == 'Register berhasil';
    }
    return false;
  }

  Future<void> logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }
}
