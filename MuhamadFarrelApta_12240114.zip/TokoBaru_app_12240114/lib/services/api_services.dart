import 'dart:convert';
import 'package:flutter/gestures.dart';
import 'package:http/http.dart' as http;
import '../models/produk.dart';

class ApiServices {
  //ini untuk emulator mobile




  final String baseUrl = "http://127.0.0.1:8000/api";

  Future<List<Produk>> fetchProduk() async {
    final response = await http.get(Uri.parse('$baseUrl/produk'));

    if (response.statusCode == 200) {
      List data = jsonDecode(response.body);
      return data.map((item) => Produk.fromJson(item)).toList();
    } else {
      throw Exception("Gagal memuat produk");
    }
      
    }

  Future<bool> addProduk(Map<String, dynamic>data) async {
    final response = await http.post(
      Uri.parse('$baseUrl/produk'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(data),
    );
    return response.statusCode == 201;
  }

  Future<bool> updateProduk(int id, Map<String, dynamic> data) async {
    final response = await http.put(
      Uri.parse('$baseUrl/produk/$id'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(data),
    );
    return response.statusCode == 200;
  }

  Future<bool> deleteProduk(int id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/produk/$id'),
      headers: {'Content-Type': 'application/json'},
    );
    return response.statusCode == 200;
  }
  }
