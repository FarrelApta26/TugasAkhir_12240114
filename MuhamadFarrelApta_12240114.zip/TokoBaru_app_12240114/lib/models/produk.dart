class Produk{
  final int id;
  final String kodeProduk;
  final String namaProduk;
  final int harga;

  Produk({
    required this.id,
    required this.kodeProduk,
    required this.namaProduk,
    required this.harga,
  });

  factory Produk.fromJson(Map<String, dynamic> json) {
    return Produk(
      id: json['id'],
      kodeProduk: json['kode_produk'],
      namaProduk: json['nama_produk'],
      harga: json['harga'],
    );
  }
}