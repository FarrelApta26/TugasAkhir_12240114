import 'package:flutter/material.dart';
import 'package:tokokita_app/models/produk.dart';
import 'package:tokokita_app/services/api_services.dart';

class ProdukEditPage extends StatefulWidget {
  final Produk produk;

  const ProdukEditPage({super.key, required this.produk});

  @override
  State<ProdukEditPage> createState() => _ProdukEditPageState();
}

class _ProdukEditPageState extends State<ProdukEditPage> {
  final kodeController = TextEditingController();
  final namaController = TextEditingController();
  final hargaController = TextEditingController();

  bool isLoading = false;
  final ApiServices apiService = ApiServices();

  @override
  void initState() {
    super.initState();
    kodeController.text = widget.produk.kodeProduk;
    namaController.text = widget.produk.namaProduk;
    hargaController.text = widget.produk.harga.toString();
  }

  Future<void> _updateProduk() async {
    if (kodeController.text.isEmpty ||
        namaController.text.isEmpty ||
        hargaController.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Semua field wajib diisi")));
      return;
    }

    setState(() => isLoading = true);

    final data = {
      "kode_produk": kodeController.text,
      "nama_produk": namaController.text,
      "harga": int.tryParse(hargaController.text) ?? 0,
    };

    final response = await apiService.updateProduk(widget.produk.id, data);

    setState(() => isLoading = false);

    if (response) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Produk berhasil diperbarui!")),
      );

      Navigator.pop(context, true); // kembali ke list & trigger refresh
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Gagal memperbarui produk")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Edit Produk")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: kodeController,
                decoration: const InputDecoration(
                  labelText: "Kode Produk",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: namaController,
                decoration: const InputDecoration(
                  labelText: "Nama Produk",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: hargaController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Harga",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 25),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: isLoading ? null : _updateProduk,
                  child: isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text("Simpan Perubahan"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
