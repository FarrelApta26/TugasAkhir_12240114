import 'package:flutter/material.dart';
import 'package:tokokita_app/services/api_services.dart';

class ProdukAddPage extends StatefulWidget {
  const ProdukAddPage({super.key});

  @override
  State<ProdukAddPage> createState() => _ProdukAddPageState();
}

class _ProdukAddPageState extends State<ProdukAddPage> {
  final kodeController = TextEditingController();
  final namaController = TextEditingController();
  final hargaController = TextEditingController();

  bool isLoading = false;
  final ApiServices apiService = ApiServices();

  Future<void> _simpanProduk() async {
    if (kodeController.text.isEmpty ||
        namaController.text.isEmpty ||
        hargaController.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Semua field wajib diisi")));
      return;
    }

    setState(() => isLoading = true);

    final data = {
      "kode_produk": kodeController.text,
      "nama_produk": namaController.text,
      "harga": int.tryParse(hargaController.text) ?? 0,
    };

    final response = await apiService.addProduk(data);

    setState(() => isLoading = false);

    if (response) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Produk berhasil ditambahkan!")),
      );

      Navigator.pop(context, true); // kembali ke list & trigger refresh
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Gagal menambahkan produk")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Tambah Produk")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: kodeController,
                decoration: const InputDecoration(
                  labelText: "Kode Produk",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: namaController,
                decoration: const InputDecoration(
                  labelText: "Nama Produk",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: hargaController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Harga",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 25),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: isLoading ? null : _simpanProduk,
                  child: isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text("Simpan Produk"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
