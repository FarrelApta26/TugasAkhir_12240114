import 'package:flutter/material.dart';
import 'package:tokokita_app/services/api_services.dart';
import '../models/produk.dart';
import 'produk_details.dart';
import 'produk_add.dart';
import 'produk_edit.dart';


class ProdukPage extends StatefulWidget {
  const ProdukPage({super.key});

  @override
  State<ProdukPage> createState() => _ProdukPageState();
}

class _ProdukPageState extends State<ProdukPage> {
  final ApiServices api = ApiServices();
  late Future<List<Produk>> futureProduk;

  @override
  void initState() {
    super.initState();
    futureProduk = api.fetchProduk();
  }

  // reload data ketika ada perubahan
  void _refreshData() {
    setState(() {
      futureProduk = api.fetchProduk();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Toko Kita")),

      body: FutureBuilder<List<Produk>>(
        future: futureProduk,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Tidak ada produk"));
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final produk = snapshot.data![index];
              return ListTile(
                title: Text(produk.namaProduk),
                subtitle: Text("Kode: ${produk.kodeProduk}\nHarga: Rp ${produk.harga}"),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DetailProdukPage(produk: produk),
                    ),
                  ).then((_) {
                    // 🔥 Refresh data ketika kembali dari detail page
                    _refreshData();
                  });
                },
                trailing: IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProdukEditPage(produk: produk),
                      ),
                    ).then((value) {
                      if (value == true) {
                        _refreshData();
                      }
                    });
                  },
                ),
              );
            },
          );
        },
      ),

      // ============================================
      // 🔥 Floating Button untuk Tambah Produk
      // ============================================
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ProdukAddPage()),
          ).then((value) {
            if (value == true) {
              _refreshData();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Produk berhasil ditambahkan")),
              );
            }
          });
        },
      ),
    );
  }
}
