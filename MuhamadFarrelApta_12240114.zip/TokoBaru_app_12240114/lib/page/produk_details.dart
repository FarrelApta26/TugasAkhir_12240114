import 'package:flutter/material.dart';
import '../models/produk.dart';
import 'produk_edit.dart';
import 'package:tokokita_app/services/api_services.dart';

class DetailProdukPage extends StatelessWidget {
  final Produk produk;

  const DetailProdukPage({super.key, required this.produk});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(produk.namaProduk)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 200,
              width: double.infinity,
              color: Colors.grey[300],
              child: const Icon(Icons.image, size: 80, color: Colors.black54),
            ),

            const SizedBox(height: 20),

            Text(
              produk.namaProduk,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 10),

            Text(
              "Kode Produk: ${produk.kodeProduk}",
              style: const TextStyle(fontSize: 16),
            ),

            const SizedBox(height: 10),

            Text(
              "Harga: Rp ${produk.harga}",
              style: const TextStyle(
                fontSize: 18,
                color: Colors.green,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 30),

            Row(
              children: [
                // ------------ BUTTON EDIT -------------
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.edit, color: Colors.blue),
                    label: const Text(
                      "Edit",
                      style: TextStyle(color: Colors.blue),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ProdukEditPage(produk: produk),
                        ),
                      );
                    },
                  ),
                ),

                const SizedBox(width: 10),

                // ------------ BUTTON HAPUS -------------
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    label: const Text(
                      "Hapus",
                      style: TextStyle(color: Colors.red),
                    ),
                    onPressed: () {
                      _konfirmasiHapus(context);
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // DIALOG KONFIRMASI HAPUS
  void _konfirmasiHapus(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Hapus Produk"),
          content: Text(
            "Apakah Anda yakin ingin menghapus ${produk.namaProduk}?",
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Batal"),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () {
                Navigator.pop(context); // tutup dialog
                _hapusProduk(context);
              },
              child: const Text("Hapus"),
            ),
          ],
        );
      },
    );
  }

  // FUNGSI HAPUS PRODUK
  void _hapusProduk(BuildContext context) async {
    final apiService = ApiServices();
    final success = await apiService.deleteProduk(produk.id);

    if (success) {
      // 🔥 Langsung ke halaman utama (ProdukPage)
      Navigator.popUntil(context, (route) => route.isFirst);
      
      // Tampilkan snackbar di halaman utama
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Produk berhasil dihapus ✓")),
      );
    } else {
      // Jika gagal, tampilkan snackbar (halaman tidak ditutup)
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal menghapus produk")),
      );
    }
  }
}
